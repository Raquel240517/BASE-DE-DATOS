create database expedientes_pacientes;
use expedientes_pacientes;
create table quirofano(
clave_quirofano int not null primary key,
ubicaci�n varchar(200) not null);

create table medico_general(
cedula_medico_general int not null primary key,
primer_nombre varchar(100) not null,
segundo_nombre varchar(100) null,
primer_apellido varchar(100) not null,
segundo_apellido varchar(100) null,
fecha_titulacion date not null);


create table tipo_consulta(
clave_consulta int not null primary key,
tipo_consulta_general varchar(200) not null,
tipo_consulta_especialista varchar(200) not null);


create table medicamento(
clave_medicamento int not null primary key,
nombre_medicamento varchar(200) not null);


create table enfermedad(
clave_enfermedad int not null primary key,
nombre_enfermedad varchar(200) not null,
descripcion varchar(500) not null);

create table especialidad(
clave_especialidad int not null primary key,
nombre_especialidad varchar(100) not null);

create table medico_especialista(
cedula_medico_especialista int not null primary key,
primer_nombre varchar(100) not null,
segundo_nombre varchar(100) null,
primer_apellido varchar(100) not null,
segundo_apellido varchar(100) null,
a�os_experiencia date not null);

create table expediente(
no_expediente int not null primary key,
carnet_paciente int not null references paciente(carnet_paciente));


create table paciente(
carnet_paciente int not null primary key,
primer_nombre varchar(100) not null,
segundo_nombre varchar(100) null,
primer_apellido varchar(100) not null,
segundo_apellido varchar(100) null,
calle varchar(100) not null,
no_exterior varchar(20) not null,
no_interior varchar(20) null,
manzana varchar(20) null,
lote varchar(20) not null,
colonia varchar(100) not null,
cp int not null,
delegacion_municipio varchar(100) not null,
ciudad_estado varchar(100) not null,
edad varchar(20) not null,
sexo varchar(30) not null);

create table operaciones(
clave_operacion int not null primary key,
descripcion varchar(200) not null,
clave_quirofano int not null references quirofano(clave_quirofano));


create table receta(
clave_receta int not null primary key,
no_receta int not null,
descripcion varchar(200) not null,
carnet_paciente int not null references paciente(carnet_paciente));


create table consulta(
clave_de_consulta int not null primary key,
hora_consulta int not null,
fecha_consulta date not null,
no_consultorio int not null,
no_analisis int null,
descripcion_consulta varchar(200) null,
cedula_medico_general int not null references medico_general(cedula_medico_general),
clave_especialidad int not null references especialidad (clave_especialidad),
clave_consulta int not null references tipo_consulta (clave_consulta));


create table especialidad_medico(
clave_especialidad int not null references especialidad(clave_especialidad),
cedula_medico_especialista int not null references medico_especialista(cedula_medico_especialista),
primary key(clave_especialidad,cedula_medico_especialista));


create table especialista_operaciones(
cedula_medico_especialista int not null references medico_especialista(cedula_medico_especialista),
clave_operacion int not null references operaciones(clave_operacion),
primary key(cedula_medico_especialista,clave_operacion));


create table expediente_operaciones(
no_expediente int not null references expediente(no_expediente),
clave_operacion int not null references operaciones(clave_operacion),
primary key(no_expediente,clave_operacion));


create table expediente_enfermedad(
clave_enfermedad int not null references enfermedad(clave_enfermedad),
no_expediente int not null references expediente(no_expediente),
primary key(clave_enfermedad,no_expediente));

create table medicamento_receta(
clave_receta int not null references receta(clave_receta),
clave_medicamento int not null references medicamento (clave_medicamento),
primary key(clave_receta,clave_medicamento));
